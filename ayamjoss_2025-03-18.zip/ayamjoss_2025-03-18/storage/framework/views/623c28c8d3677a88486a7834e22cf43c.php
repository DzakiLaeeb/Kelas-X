<?php $__env->startSection('content'); ?>
<div class="admin-container">
    <h2 class="admin-heading">Daftar Pelanggan</h2>

    <div class="card admin-card">
        <div class="card-body">
            <table class="table table-admin">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Nama</th>
                        <th>Email</th>
                        <th>Telepon</th>
                        <th>Alamat</th>
                        <th>Jenis Kelamin</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $pelanggans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pelanggan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($loop->iteration); ?></td>
                        <td><?php echo e($pelanggan->pelanggan); ?></td>
                        <td><?php echo e($pelanggan->email); ?></td>
                        <td><?php echo e($pelanggan->telp); ?></td>
                        <td><?php echo e($pelanggan->alamat); ?></td>
                        <td><?php echo e($pelanggan->jeniskelamin == 'L' ? 'Laki-laki' : 'Perempuan'); ?></td>
                        <td>
                            <div class="action-btns">
                                <a href="<?php echo e(route('admin.pelanggan.edit', $pelanggan->idpelanggan)); ?>" class="btn btn-sm btn-admin-secondary">
                                    <i class="fas fa-edit"></i>
                                </a>
                                <form action="<?php echo e(route('admin.pelanggan.destroy', $pelanggan->idpelanggan)); ?>" method="POST" class="d-inline">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-sm btn-danger" onclick="return confirm('Yakin ingin menghapus?')">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                </form>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="7" class="text-center">Tidak ada data pelanggan</td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xamppnew\htdocs\belajar laravel\resources\views/admin/pelanggan/index.blade.php ENDPATH**/ ?>