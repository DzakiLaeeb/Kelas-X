

<?php $__env->startSection('content'); ?>
<div class="contact-container">
    <div class="row">
        <div class="col-md-6">
            <div class="contact-info-card">
                <h2 class="section-title">Hubungi Kami</h2>
                <div class="info-item">
                    <i class="fas fa-map-marker-alt"></i>
                    <div>
                        <h4>Alamat</h4>
                        <p>Jl. Raya Contoh No. 123, Kota, Indonesia</p>
                    </div>
                </div>
                <div class="info-item">
                    <i class="fas fa-phone"></i>
                    <div>
                        <h4>Telepon</h4>
                        <p>+62 812-3456-7890</p>
                    </div>
                </div>
                <div class="info-item">
                    <i class="fas fa-envelope"></i>
                    <div>
                        <h4>Email</h4>
                        <p>info@ayamgorengjoss.com</p>
                    </div>
                </div>
                <div class="info-item">
                    <i class="fas fa-clock"></i>
                    <div>
                        <h4>Jam Operasional</h4>
                        <p>Senin - Minggu: 10:00 - 22:00</p>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-6">
            <div class="contact-form-card">
                <h2 class="section-title">Kirim Pesan</h2>
                
                <?php if(session('success')): ?>
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <?php echo e(session('success')); ?>

                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                <?php endif; ?>

                <?php if($errors->any()): ?>
                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                        <ul class="mb-0">
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                <?php endif; ?>

                <form action="<?php echo e(route('kontak.send')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="mb-3">
                        <label for="name" class="form-label">Nama</label>
                        <input type="text" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                               id="name" name="name" value="<?php echo e(old('name')); ?>" required>
                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="mb-3">
                        <label for="email" class="form-label">Email</label>
                        <input type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                               id="email" name="email" value="<?php echo e(old('email')); ?>" required>
                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="mb-3">
                        <label for="subject" class="form-label">Subjek</label>
                        <input type="text" class="form-control <?php $__errorArgs = ['subject'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                               id="subject" name="subject" value="<?php echo e(old('subject')); ?>" required>
                        <?php $__errorArgs = ['subject'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="mb-3">
                        <label for="message" class="form-label">Pesan</label>
                        <textarea class="form-control <?php $__errorArgs = ['message'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                  id="message" name="message" rows="4" required><?php echo e(old('message')); ?></textarea>
                        <?php $__errorArgs = ['message'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <button type="submit" class="btn btn-send">Kirim Pesan</button>
                </form>
            </div>
        </div>
    </div>
</div>

<style>
.contact-container {
    padding: 2rem 0;
}

.section-title {
    color: var(--primary-red);
    font-weight: 700;
    margin-bottom: 1.5rem;
    position: relative;
}

.contact-info-card,
.contact-form-card {
    background-color: var(--card-bg);
    padding: 2rem;
    border-radius: 15px;
    box-shadow: var(--card-shadow);
    height: 100%;
    transition: all 0.3s ease;
}

.info-item {
    display: flex;
    align-items: flex-start;
    margin-bottom: 1.5rem;
    padding: 1rem;
    background-color: var(--bg-color);
    border-radius: 10px;
    transition: all 0.3s ease;
}

.info-item:hover {
    transform: translateY(-3px);
    box-shadow: var(--card-shadow-hover);
}

.info-item i {
    font-size: 1.5rem;
    color: var(--primary-red);
    margin-right: 1rem;
    margin-top: 0.2rem;
}

.info-item h4 {
    color: var(--text-color);
    font-size: 1.1rem;
    margin-bottom: 0.3rem;
}

.info-item p {
    color: var(--text-secondary);
    margin-bottom: 0;
}

.form-label {
    color: var(--text-color);
    font-weight: 500;
}

.form-control {
    background-color: var(--bg-color);
    border: 1px solid var(--text-secondary);
    color: var(--text-color);
    padding: 0.8rem;
    border-radius: 8px;
    transition: all 0.3s ease;
}

.form-control:focus {
    border-color: var(--primary-red);
    box-shadow: 0 0 0 0.2rem rgba(230, 57, 70, 0.25);
    background-color: var(--bg-color);
    color: var(--text-color);
}

.btn-send {
    background-color: var(--primary-red);
    color: white;
    padding: 0.8rem 2rem;
    border-radius: 30px;
    border: none;
    font-weight: 600;
    transition: all 0.3s ease;
}

.btn-send:hover {
    background-color: var(--primary-yellow);
    transform: translateY(-2px);
    color: var(--dark-brown);
}

/* Dark Mode Styles */
[data-bs-theme="dark"] .contact-info-card,
[data-bs-theme="dark"] .contact-form-card {
    background-color: var(--card-bg);
    box-shadow: 0 4px 15px rgba(0, 0, 0, 0.3);
}

[data-bs-theme="dark"] .info-item {
    background-color: #282828;
}

[data-bs-theme="dark"] .form-control {
    background-color: #282828;
    border-color: #404040;
    color: #e0e0e0;
}

[data-bs-theme="dark"] .form-control:focus {
    background-color: #282828;
    border-color: var(--primary-red);
    color: #e0e0e0;
}

[data-bs-theme="dark"] .form-control::placeholder {
    color: #808080;
}

[data-bs-theme="dark"] .info-item:hover {
    background-color: #333333;
}

[data-bs-theme="dark"] .btn-send {
    background-color: var(--primary-red);
    color: white;
}

[data-bs-theme="dark"] .btn-send:hover {
    background-color: var(--primary-yellow);
    color: #121212;
}

/* Responsive Adjustments */
@media (max-width: 768px) {
    .contact-info-card,
    .contact-form-card {
        margin-bottom: 2rem;
    }
    
    .info-item {
        padding: 0.8rem;
    }
}

/* Add these to your existing styles */
.alert {
    border-radius: 10px;
    margin-bottom: 1.5rem;
}

.alert-success {
    background-color: rgba(25, 135, 84, 0.1);
    border-color: #198754;
    color: #198754;
}

.alert-danger {
    background-color: rgba(220, 53, 69, 0.1);
    border-color: #dc3545;
    color: #dc3545;
}

[data-bs-theme="dark"] .alert-success {
    background-color: rgba(25, 135, 84, 0.2);
    color: #75b798;
}

[data-bs-theme="dark"] .alert-danger {
    background-color: rgba(220, 53, 69, 0.2);
    color: #ea868f;
}

.alert ul {
    padding-left: 1rem;
}
</style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xamppnew\htdocs\belajar laravel\resources\views/kontak.blade.php ENDPATH**/ ?>