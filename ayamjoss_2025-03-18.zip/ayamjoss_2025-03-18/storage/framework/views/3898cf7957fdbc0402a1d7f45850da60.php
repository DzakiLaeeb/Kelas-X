<?php $__env->startSection('content'); ?>
<div class="admin-container">
    <h2 class="admin-heading">Daftar Kategori</h2>
    
    <div class="mb-3">
        <a href="<?php echo e(route('admin.kategori.create')); ?>" class="btn btn-admin-primary">
            <i class="fas fa-plus me-2"></i>Tambah Kategori
        </a>
    </div>

    <div class="card admin-card">
        <div class="card-body">
            <table class="table table-admin">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Nama</th>
                        <th>Slug</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $kategoris; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kategori): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($loop->iteration); ?></td>
                        <td><?php echo e($kategori->nama); ?></td>
                        <td><?php echo e($kategori->slug); ?></td>
                        <td>
                            <div class="action-btns">
                                <a href="<?php echo e(route('admin.kategori.edit', $kategori->id)); ?>" class="btn btn-sm btn-admin-secondary">
                                    <i class="fas fa-edit"></i>
                                </a>
                                <form action="<?php echo e(route('admin.kategori.destroy', $kategori->id)); ?>" method="POST" class="d-inline">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-sm btn-danger" onclick="return confirm('Yakin ingin menghapus?')">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                </form>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xamppnew\htdocs\belajar laravel\resources\views/admin/kategori/index.blade.php ENDPATH**/ ?>