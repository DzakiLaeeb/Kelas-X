<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <!-- Cards -->
    <div class="row">
        <div class="col-md-4">
            <div class="card">
                <div class="card-body">
                    <h5>Penjualan Hari Ini</h5>
                    <h3>Rp <?php echo e(number_format($today_sales, 0, ',', '.')); ?></h3>
                    <p><?php echo e($today_orders); ?> pesanan</p>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card">
                <div class="card-body">
                    <h5>Penjualan Bulan Ini</h5>
                    <h3>Rp <?php echo e(number_format($month_sales, 0, ',', '.')); ?></h3>
                    <p><?php echo e($month_orders); ?> pesanan</p>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card">
                <div class="card-body">
                    <h5>Total Pelanggan</h5>
                    <h3><?php echo e($total_customers); ?></h3>
                </div>
            </div>
        </div>
    </div>

    <!-- Chart -->
    <div class="card mt-4">
        <div class="card-body">
            <h5>Grafik Penjualan</h5>
            <canvas id="salesChart"></canvas>
        </div>
    </div>
</div>

<?php $__env->startPush('scripts'); ?>
<script>
// Pastikan data valid sebelum membuat chart
const labels = <?php echo json_encode($chart_labels, 15, 512) ?>;
const data = <?php echo json_encode($chart_data, 15, 512) ?>;

// Tunggu sampai DOM selesai dimuat
document.addEventListener('DOMContentLoaded', function() {
    const ctx = document.getElementById('salesChart').getContext('2d');
    
    new Chart(ctx, {
        type: 'line',
        data: {
            labels: labels,
            datasets: [{
                label: 'Penjualan',
                data: data,
                borderColor: '#4e73df',
                tension: 0.1,
                fill: false
            }]
        },
        options: {
            responsive: true,
            scales: {
                y: {
                    beginAtZero: true
                }
            }
        }
    });
});
</script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xamppnew\htdocs\belajar laravel\resources\views/admin/laporan/index.blade.php ENDPATH**/ ?>