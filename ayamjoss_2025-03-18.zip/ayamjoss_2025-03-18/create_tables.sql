CREATE TABLE menus (
    idmenu BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    kategori_id BIGINT UNSIGNED NOT NULL,
    nama VARCHAR(255) NOT NULL,
    deskripsi VARCHAR(255) NOT NULL,
    harga DECIMAL(10,2) NOT NULL,
    gambar VARCHAR(255) NOT NULL,
    badge VARCHAR(255) NULL,
    badge_type VARCHAR(255) NULL,
    created_at TIMESTAMP NULL,
    updated_at TIMESTAMP NULL,
    CONSTRAINT fk_kategori FOREIGN KEY (kategori_id) 
        REFERENCES kategoris(id) ON DELETE CASCADE
) ENGINE=InnoDB;

INSERT INTO menus (kategori_id, nama, deskripsi, harga, gambar, badge, badge_type) VALUES
(1, 'Ayam Goreng Original', 'Ayam goreng renyah dengan bumbu rahasia', 25000, 
'https://images.unsplash.com/photo-1626645738196-c2a7c87a8f58?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=870&q=80', 
'Bestseller', 'normal'),

(1, 'Ayam Goreng Pedas', 'Ayam goreng dengan bumbu pedas', 27000,
'https://images.unsplash.com/photo-1562967914-608f82629710?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=873&q=80',
'Pedas', 'hot'),

(2, 'Ayam Bakar Madu', 'Ayam bakar dengan olesan madu spesial', 28000,
'https://images.unsplash.com/photo-1555939594-58d7cb561ad1?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=774&q=80',
'New', 'new');

