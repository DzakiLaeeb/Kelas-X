import './bootstrap';

// Hapus fungsi logout jika ada
// function logout() {
//     document.getElementById('logout-form').submit();
// }


